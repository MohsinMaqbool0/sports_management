<?php 
define('EMAIL', 'projecthtml01@gmail.com');
define('PASS', 'erng tqrk ymju sina');

?>